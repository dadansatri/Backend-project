<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');
$routes->get('/login', 'Auth::login');
$routes->setDefaultController('Auth');
$routes->get('/register', 'Auth::register');
$routes->get('/helloworld', 'Helloworld::index');
$routes->get('/page', 'page::index');
$routes->get('/page1', 'page1::index');
$routes->get('/login', 'Pa::login');

